import java.util.Map;

/**
 * The type Times.
 */
public class Times {
    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {

        Map MAP = MapBuild.getInitialValues(MapFact.getMap("3"));

    }
}